package neural.helper;

import com.image.features.FeatureExtraction;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.FileObjectHelper;
import util.ServerConstants;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.LibSVM;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class SVMClassificationPrediction {

    public Classifier nb = null;
    public String traingARFFFilePath = "";
    public String modelPath = "";
    public DataSource source = null;
    public Instances traindata = null;

    public SVMClassificationPrediction(String traingARFFFilePath, String modelPath) {
        try {
            this.traingARFFFilePath = traingARFFFilePath;
            this.modelPath = modelPath;
            this.source = new DataSource(traingARFFFilePath);
            this.traindata = source.getDataSet();
            this.traindata.setClassIndex(this.traindata.numAttributes() - 1);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public ArrayList<double[]> getSVMTrainingData() {
        DataSource test;
        try {
            test = new DataSource(this.traingARFFFilePath);

            Instances testData = test.getDataSet();
            if (testData.classIndex() == -1) {
                testData.setClassIndex(testData.numAttributes() - 1);
            }
            ArrayList<double[]> data = new ArrayList<double[]>();
            for (int i = 0; i < testData.numInstances(); i++) {
                Instance instance = testData.instance(i);
                data.add(instance.toDoubleArray());
            }
            return data;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    public void trainSVM(boolean retrain) {
        File f = new File(traingARFFFilePath);
        if (f.exists()) {
            try {
                nb = new LibSVM();
                if (!retrain) {
                    File model = new File(modelPath);
                    if (model.exists()) {
                        nb = (Classifier) FileObjectHelper.readObject(modelPath);
                        return;
                    } else {
                        System.err.println("Model does not exist");
                    }
                }
                /**
                 * load test data
                 */
                nb.buildClassifier(this.traindata);
                int correct = 0, total = 0;
                for (int j = 0; j < traindata.numInstances(); j++) {
                    double actualClass = traindata.instance(j).classValue();
                    String actual = traindata.classAttribute().value((int) actualClass);
                    Instance newInst = traindata.instance(j);
//                    System.out.println("actual class:" + newInst.stringValue(newInst.numAttributes() - 1));
                    double preNB = nb.classifyInstance(newInst);
                    String predString = traindata.classAttribute().value((int) preNB);
                    System.out.println(actual + "," + predString);
                    if (actual.equalsIgnoreCase(predString)) {
                        correct++;
                    }
                    total++;
                }
                FileObjectHelper.saveObject(nb, modelPath);
            } catch (Exception ex) {
                Logger.getLogger(SVMClassificationPrediction.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            System.err.println("Input ARFF File does not exist " + traingARFFFilePath);
        }
    }

    public double predict(double[] features) {
        try {

            Instance newInst = traindata.instance(0);
            for (int i = 0; i < features.length; i++) {
                double d = features[i];
                newInst.setValue(i, d);
            }
            double preNB = nb.classifyInstance(newInst);
            String predString = traindata.classAttribute().value((int) preNB);
            System.out.println(" " + preNB + "====>" + predString);
            return preNB;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public void evaluate() {
        try {
            Evaluation eval = new Evaluation(traindata);
            eval.evaluateModel(nb, traindata);
            System.out.println(eval.toSummaryString("\nResults\n======\n", true));
            double[][] array = eval.confusionMatrix();
            System.out.println("Confusion Matrix --------------------------------");
            for (double[] x : array) {
                for (double y : x) {
                    System.out.print(y + ",");
                }
                System.out.println();
            }
            System.out.println("Confusion Matrix --------------------------------");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void testData(String datasetDir) {
        int classIndex = 0;

        Instance newInst = traindata.instance(0);
        int correct = 0;
        int total = 0;
        File[] files = new File(datasetDir).listFiles();
        for (File imageDirectory : files) {
            System.out.println(imageDirectory.getAbsolutePath());
            classIndex++;

            if (imageDirectory.listFiles() != null) {



                File[] iarray = imageDirectory.listFiles();
                for (int j1 = 0; j1 < iarray.length; j1++) {
                    try {
                        File imageFile = iarray[j1];
                        //        File imageFile = new File("D:\\work\\project\\CBIR-Search\\dataset\\image-classes\\beach\\101.jpg");
//                        BufferedImage newImage = ImageIO.read(imageFile);

//                        float brightenFactor = 1.2f;
//                        RescaleOp op = new RescaleOp(brightenFactor, 0, null);
//                        newImage = op.filter(newImage, newImage);
                        FeatureExtraction cedd = new FeatureExtraction();
                        double[] features = cedd.extractSingleImage(imageFile.getAbsolutePath());
                        for (int i = 0; i < features.length; i++) {
                            double d = features[i];
                            newInst.setValue(i, d);
                        }
                        double preNB = nb.classifyInstance(newInst);
                        String predString = traindata.classAttribute().value((int) preNB);
                        System.out.println(",<<<===================>>>" + predString);
                        if ((classIndex + "").equalsIgnoreCase(predString)) {
                            correct++;
                        }

                        total++;
                        System.out.println("actual class:" + newInst.stringValue(newInst.numAttributes() - 1));


                        System.out.println("Total " + correct + "/" + total);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }


                }
            }
        }
    }

    public String createARFF(File datasetDirectory) {
        StringBuffer featuresString = new StringBuffer();
        try {
            featuresString.append("@relation test\n");
            int classIndex = 0;
      
            boolean b = false;

            File[] files = datasetDirectory.listFiles();
            for (File imageDirectory : files) {
                System.out.println(imageDirectory.getAbsolutePath());


                if (imageDirectory.listFiles() != null) {



                    File[] iarray = imageDirectory.listFiles();
                    for (int j1 = 0; j1 < iarray.length; j1++) {

                        File imageFile = iarray[j1];
                        if (imageFile.isDirectory()) {
                            continue;
                        }
                        FeatureExtraction cedd = new FeatureExtraction();
                        double[] features = cedd.extractSingleImage(imageFile.getAbsolutePath());
//                        System.out.println(extractor.getFeatureName() + "=");

                        if (!b) {
                            b = true;
                            for (int i = 0; i < features.length; i++) {
                                featuresString.append("@ATTRIBUTE feature" + i + "  NUMERIC\n");
                            }
                            featuresString.append("@ATTRIBUTE outputClass  {");
                            for (int i = 0; i < files.length; i++) {
                                featuresString.append(i + ",");
                            }
                            featuresString.append("}\n");
                            featuresString.append("@DATA \n");
                        }


                        for (int i = 0; i < features.length; i++) {
                            double d = features[i];
                            System.out.print(d + ",");
                            featuresString.append(d + ",");
                        }
                        featuresString.append(classIndex + "\n");
                        System.out.println("\n");




                    }

                }
                classIndex++;
            }

            FileOutputStream fos = new FileOutputStream(new File(ServerConstants.SVM_TRAINING_ARFF));
            fos.write(featuresString.toString().getBytes());
            fos.close();
        } catch (IOException ex) {
            Logger.getLogger(SVMClassificationPrediction.class.getName()).log(Level.SEVERE, null, ex);
        }
        return featuresString.toString();
    }

    public static void main(String[] args) throws Exception {



        SVMClassificationPrediction claass = new SVMClassificationPrediction(ServerConstants.SVM_TRAINING_ARFF, ServerConstants.SVM_MODEL_FILE);

        claass.createARFF(new File(ServerConstants.DATASET_DIR));
        if (true) {
            return;
        }
        claass.trainSVM(true);
        claass.evaluate();


//        BufferedImage newImage = ImageIO.read(new File("C:\\Users\\technnowings\\Desktop\\pexels-photo-270756.jpeg"));
//        float brightenFactor = 1.2f;
//        RescaleOp op = new RescaleOp(brightenFactor, 0, null);
//        newImage = op.filter(newImage, newImage);
//
//        CEDD cedd = new CEDD();
//        cedd.extract(newImage);
//        double[] features = cedd.getFeatureVector();
//        double oop = claass.predict(features);
//        System.out.println("oop " + oop);

    }
}
