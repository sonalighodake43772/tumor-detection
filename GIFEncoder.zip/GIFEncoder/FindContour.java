package GIFEncoder;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

import org.bytedeco.javacpp.Loader;

import util.opencv.OpenCVHelper;
import static org.bytedeco.javacpp.opencv_highgui.*;

import static org.bytedeco.javacpp.opencv_core.*;
import static org.bytedeco.javacpp.opencv_imgcodecs.*;
import static org.bytedeco.javacpp.opencv_imgproc.*;
import org.bytedeco.javacpp.Loader;
import org.bytedeco.javacv.CameraDevice;
import static org.bytedeco.javacpp.opencv_core.*;
import static org.bytedeco.javacpp.opencv_imgproc.*;
import static org.bytedeco.javacpp.opencv_videoio.*;

/*
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 */
/**
 *
 * @author technowings-pc
 */
public class FindContour {

    private static CvCapture capture;

    public static void main22(String[] args) {
        try {
            File f = new File("D:/database");
            File f2[] = f.listFiles();
            for (int i = 0; i < f2.length; i++) {
                File file = f2[i];
                BufferedImage buff = ImageIO.read(file);
                IplImage ColorImage = OpenCVHelper.buffered2ipl(buff);
                IplImage ColorImage2 = cvCreateImage(new CvSize(100, 80), IPL_DEPTH_8U, 3);
                cvResize(ColorImage, ColorImage2, CV_INTER_NN);
                imwrite(System.currentTimeMillis() + ".jpg", OpenCVHelper.ipl2mat(ColorImage2));
            }

//            applyDilation(ImageIO.read(new File(FileChooserHelper.selectImageFile())));
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

    public static void main(String[] args) {


        try {
            Loader.load(org.bytedeco.javacpp.opencv_highgui.class);
        } catch (Throwable t) {
        }
//       capture = cvCreateCameraCapture(0);
//       cvRetrieveFrame(capture);
        IplImage grabbedImage = OpenCVHelper.file2ipl("D:/database\\a.jpg");
        IplImage GrayImage = cvCreateImage(cvGetSize(grabbedImage), IPL_DEPTH_8U, 1);
        cvCvtColor(grabbedImage, GrayImage, CV_BGR2GRAY);
        cvThreshold(GrayImage, GrayImage, 125, 255, CV_THRESH_BINARY);

        IplImage copyGrayImage = GrayImage.clone();
        CvMemStorage storage = CvMemStorage.create();
        CvSeq contour = new CvSeq(null);
        cvFindContours(GrayImage, storage, contour, Loader.sizeof(CvContour.class),
                CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE);
        RNG rng = new RNG(12345);
        CvRect boundRect = null;
        int i = 1;
        CvFont font = cvFont(1, 1);
        Mat m = OpenCVHelper.ipl2mat(copyGrayImage);
        while (contour != null && !contour.isNull()) {
            try {
                if (contour.elem_size() > 0) {
                    CvBox2D box = cvMinAreaRect2(contour);
                    CvScalar color = new CvScalar(rng.uniform(0, 255), rng.uniform(0, 255), rng.uniform(0, 255), 255);
                    CvSeq points = cvApproxPoly(contour, Loader.sizeof(CvContour.class),
                            storage, CV_POLY_APPROX_DP, cvContourPerimeter(contour) * 0.02, 0);
                    System.out.println("points " + points + " " + points.total());
                    cvDrawContours(GrayImage, points, CvScalar.BLUE, CvScalar.BLUE, -1, 1, CV_AA);
                    boundRect = cvBoundingRect(contour);

                    if ((boundRect.width() < 250 && boundRect.height() < 250) && (boundRect.width() > 5 && boundRect.height() > 5)) {
                        int cx = boundRect.x();
                        int cy = boundRect.y();
                        int[] pt = {(int) Math.round((double) cx / (1 << 16) - 30 / 2),
                            (int) Math.round((double) cy / (1 << 16) + 30 / 2) + 1};
                        CvScalar red = new CvScalar(0, 255, 0, 255);
                        cvPutText(grabbedImage, i + "", pt, font, red);
                        cvDrawRect(GrayImage, new CvPoint(boundRect.x(), boundRect.y()), new CvPoint(boundRect.x() + boundRect.width(), boundRect.y() + boundRect.height()), color, 2, 8, 0);


                        Mat cropped = new Mat(m, new Rect(boundRect.x(), boundRect.y(), boundRect.width(), boundRect.height()));

                        imwrite("" + System.currentTimeMillis() + ".jpg", cropped);
                        System.out.println(" " + boundRect.x() + " " + boundRect.y() + " " + boundRect.width() + " " + boundRect.height());
                    }
                }

            } catch (Error e) {
                e.printStackTrace();
            }
            contour = contour.h_next();
        }
        cvSaveImage("op.jpg", GrayImage);
        cvShowImage("RawImage", GrayImage);
        cvWaitKey();
//        IplImage binaryImage=null;
//CvSeq contour = new CvContour(null);
//
//
//       CvMemStorage storage = CvMemStorage.create();
//    int contourPointsSize = 0;
//    IntPointer intPointer = new IntPointer(1);
//    CvPoint contourPoints = null;
//    IntBuffer contourPointsBuffer = null;
//    CvMoments moments = new CvMoments();
//        cvFindContours(binaryImage, storage, contour, Loader.sizeof(CvContour.class),
//                CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
//        double largestContourEdgeArea = 0;
//        CvSeq largestContour = null;
//        while (contour != null && !contour.isNull()) {
//            contourPointsSize = contour.total();
//            if (contourPoints == null || contourPoints.capacity() < contourPointsSize) {
//                contourPoints = new CvPoint(contourPointsSize);
//                contourPointsBuffer = contourPoints.asByteBuffer().asIntBuffer();
//            }
//            cvCvtSeqToArray(contour, contourPoints.position(0));
//
//
//            double m00 = 0, m10 = 0, m01 = 0;
//            for (int i = 0; i < contourPointsSize; i++) {
//                int x = contourPointsBuffer.get(2*i    ),
//                    y = contourPointsBuffer.get(2*i + 1);
//            }
//            double contourEdgeArea = m00*Math.abs(cvContourArea(contour, CV_WHOLE_SEQ, 0));
////            if (contourEdgeArea > contourEdgeAreaMin && contourEdgeArea < contourEdgeAreaMax &&
////                    contourEdgeArea > largestContourEdgeArea) {
////                largestContourEdgeArea = contourEdgeArea;
////                largestContour = contour;
////
////                double inv_m00 = 1 / m00;
//////                edgeX = m10 * inv_m00;
//////                edgeY = m01 * inv_m00;
////            }
//            contour = contour.h_next();
//        }

    }
}
