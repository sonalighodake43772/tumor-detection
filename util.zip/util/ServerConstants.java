/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author technowings
 */
public class ServerConstants {

    public static String WORKSPACE_PATH = "D:/work/project/BrainTumorDetectionNetbeans/";	// 2 files are 
    
    
    public static String DATASET_DIR = WORKSPACE_PATH + "dataset-new/dataset/";	// 2 files are 
    
    
    public static String NEURAL_MODEL_FILE = WORKSPACE_PATH + "dataset-new/network.bin";	// 2 files are 
    public static String SVM_TRAINING_ARFF = WORKSPACE_PATH + "dataset-new/svmTraining.arff";	// 2 files are 
    public static String SVM_MODEL_FILE = WORKSPACE_PATH + "dataset-new/svmModel.bin";	// 2 files are 
    public static String SVM_TRAINING_CSV = WORKSPACE_PATH + "dataset-new/training.csv";	// 2 files are 
    public static String DIR = "D:\\temp\\";
    public static String DICOM_DATA_DIR = WORKSPACE_PATH + "dataset-new/";
}
