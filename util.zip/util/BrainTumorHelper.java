/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.File;
import java.io.IOException;
import knn.KNN;
import org.bytedeco.javacpp.DoublePointer;
import org.bytedeco.javacpp.indexer.*;
import org.bytedeco.javacpp.indexer.UByteIndexer;
import org.bytedeco.javacpp.opencv_core;
import static org.bytedeco.javacpp.opencv_core.*;
import static org.bytedeco.javacpp.opencv_imgcodecs.*;
import static org.bytedeco.javacpp.opencv_imgproc.*;
import util.opencv.OpenCVHelper;

/**
 *
 * @author technowings
 */
public class BrainTumorHelper {
// OpenCV H has values from 0 to 180, S and V from 0 to 255

    public static void main(String[] args) {
//        Mat rawImage = imread("D:\\work\\project\\LungNoduleDetection\\dataset\\images-lung\\benign\\000013.dcm.png",CV_LOAD_IMAGE_COLOR);
//        Mat rawImage = imread("C:\\Users\\technnowings\\Pictures\\109513.jpg");



//        File pic = new File("D:\\work\\project\\BrainMRI\\test2_p004000010_2.jpg");
//        process(pic);
//        if (true) {
//            return;
//        }

        File dir = new File("D:\\work\\project\\BrainMRI\\test\\");
//        File[] dirs = dir.listFiles();
//        for (int i = 0; i < dirs.length; i++) {
//            File file = dirs[i];
//            if (!file.isDirectory()) {
//                continue;
//            }
        File[] images = dir.listFiles();
        for (int j = 0; j < images.length; j++) {
            File file1 = images[j];
            try {
//                if (file1.getName().equalsIgnoreCase("615_left.jpeg")) {
                process(file1);
//                }
            } catch (Error e) {
                e.printStackTrace();
            }

//            }
        }
    }
//        File f = new File("C:\\Users\\rajesh\\Desktop\\New folder (2)");
//        File[] a = f.listFiles();
//        for (int i = 0; i < a.length; i++) {
//            File file = a[i];
//            BufferedImage bufferedImage = ImageIO.read(file);
//            BufferedImage bimage = new BufferedImage(bufferedImage.getWidth(null), bufferedImage.getHeight(null), BufferedImage.TYPE_INT_RGB);
//
//            Graphics2D g = bimage.createGraphics();
//            g.drawImage(bufferedImage, 0, 0, null);
//            g.dispose();
//
//
//            ImageIO.write(bimage, "png", new File("C:\\Users\\rajesh\\Desktop\\New folder (2)\\" + file.getName() + ".png"));
//        }
//}
    public static Mat kernel = null;

    static {
        int kernelSize = 9;
        kernel = createKernel(kernelSize);
    }

    public static Mat createKernel(int kernelSize) {
//         int kernelSize = 9;
        Mat kernel2 = Mat.ones(new Size(kernelSize, kernelSize), CV_32F).asMat();
        double d = 1.0 / (kernelSize * kernelSize);
        kernel2 = multiply(kernel2, d).asMat();
        FloatRawIndexer imagePixels = kernel2.createIndexer();
//                Mat max=new Mat(1,4,1);
//                double d[]=new double[10];
//		minMaxLoc(hsvImage, d);
//                System.out.println("max "+max+" "+d[0]);
        float max = -1;
        for (int row = 0; row < kernel2.rows(); row++) {
//            System.out.print(row + ",");
            for (int col = 0; col < kernel2.cols(); col++) {
// if(mat.get(row, col)!=255&&mat.get(row, col)!=0)
                max = imagePixels.get(row, col);
//                System.out.print(max + ",");
//                  
            }
//            System.out.print("\n");
        }
        return kernel2;
    }
//    public static void main(String[] args) {
//        File dir = new File("D:\\work\\project\\Lung-Image-dataset\\LungCancerDetection-matlab\\Code\\TestImages\\000038.jpg");
//        process(dir);
//    }
    public static String DIR = ServerConstants.DIR;
    public static int nonZeroTumor = 0;
    public static int CANCEROUS_ = 200;

    public static void process(File file1) {


        String name = file1.getName();
        if (!(name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".bmp"))) {
            System.err.println("Invalid File Format");
            return;
        }
        // read input image
        Mat rawImage = OpenCVHelper.file2mat(file1.getAbsolutePath());
//        imwrite(DIR + name + "_contourImage3.png.png", rawImage);
//        System.out.println(" rawImage " + rawImage);

        // convert color image to grayscale
        Mat grayImage = new Mat(rawImage.size(), CV_32FC4);
        cvtColor(rawImage, grayImage, CV_BGR2GRAY);

        imwrite(DIR + name + "_gray.png", grayImage);
//        System.out.println("grayImage " + grayImage);
        Mat grayImageCopy = grayImage.clone();

//        CLAHE clahe = createCLAHE(5, new Size(8, 8));
//        Mat clahe_op = new Mat(rawImage.size(), CV_8UC1);
//        clahe.apply(grayImage, clahe_op);
//        imwrite(DIR + name + "clahe_op.png", clahe_op);




//        DoublePointer minVal = new DoublePointer(1);
//        DoublePointer maxVal = new DoublePointer(1);
//        Point min = new Point();
//        Point max = new Point();
//
//        minMaxLoc(grayImage, minVal, maxVal, min, max, null);

//        System.out.println("max " + max + " \n" + min + " \nminPoint " + minVal + " \nmaxPoint " + maxVal);
//
//
//
//        System.out.println("max " + min.x() + " " + min.y());
//        System.out.println("max " + max.x() + " " + max.y());
//
//        System.out.println("min " + minVal.get() + " max  " + maxVal.get());


//        double t0 = 60;
//        double th = t0 + (((maxVal.get()) + minVal.get()) / 2);
//        threshold(grayImage, grayImage, th, 255, CV_THRESH_BINARY);

//        double t0 = 10;
//        double th = t0 + (((maxVal.get()) + minVal.get()) / 2);



        threshold(grayImage, grayImage, 125, 255, CV_THRESH_BINARY);

        
        imwrite(DIR + name + "_threshold_5.png", grayImage);
        Mat my_kernel = createKernel(5);
        morphologyEx(grayImage, grayImage, MORPH_CLOSE, my_kernel);
        imwrite(DIR + name + "morph_close.png", grayImage);
        my_kernel = createKernel(6);
        dilate(grayImage, grayImage, my_kernel);

        imwrite(DIR + name + "morph_dilate.png", grayImage);
//          System.out.println("max " + minVal.);
        Mat threshold = grayImage.clone();
        imwrite(DIR + name + "_threshold0.png", threshold);



        MatVector contours = new MatVector();
        Mat contourImage = grayImage.clone();

        findContours(contourImage, contours, CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE); // CV_RETR_EXTERNAL   CV_RETR_LIST
        for (int contourIndex = 0; contourIndex < contours.size(); contourIndex++) {
            Mat currentContour = contours.get(contourIndex);
            if (currentContour != null) {

                Rect boundRect = boundingRect(currentContour);
                int count = countNonZero(new Mat(contourImage, boundRect));

                int cx = boundRect.x();
                int cy = boundRect.y();
                int contour_width = boundRect.width();
                int contour_height = boundRect.height();
                int thickness = CV_FILLED;//CV_FILLED 1
                Point shiftPoint = new Point(0, 0);
                int maxlevel = 0;
//                System.out.println(" " + cx + " " + cy + " " + contour_width + " " + contour_height);
                if (contour_width > (grayImage.cols() * 0.5) && contour_height > (grayImage.rows() * 0.5)) {
//                    System.out.println(" in here ");
                    //drawContours(contourImage, contours, contourIndex, Scalar.WHITE, CV_FILLED,8 ,null,0,new Point());
//                    rectangle(rawImage, new Point(cx, cy), new Point(cx + contour_width, cy + contour_height), Scalar.RED, 1, 8, 0);
                    
                    Mat pointsArra = new Mat();
                    convexHull(currentContour, pointsArra);

//                    
                    polylines(rawImage, new MatVector(pointsArra), true, Scalar.BLUE);
                     fillPoly(rawImage, new MatVector(pointsArra), Scalar.GREEN);
                    fillPoly(contourImage, new MatVector(pointsArra), Scalar.WHITE);
//                    drawContours(contourImage, new MatVector(pointsArra), thickness, Scalar.WHITE);
//                    
//                    drawContours(rawImage, new MatVector(pointsArra), thickness, Scalar.GREEN);
//                    drawContours(contourImage, contours, contourIndex, Scalar.WHITE, thickness, 8, null, maxlevel, shiftPoint);

//                    drawContours(rawImage, contours, contourIndex, Scalar.GREEN, thickness, 8, null, maxlevel, shiftPoint);
                } else {
                    drawContours(contourImage, contours, contourIndex, Scalar.BLACK, thickness, 8, null, maxlevel, shiftPoint);

                    drawContours(rawImage, contours, contourIndex, Scalar.RED, thickness, 8, null, maxlevel, shiftPoint);
                }

            }

        }



        imwrite(DIR + name + "_threshold1.png", rawImage);
        bitwise_and(threshold, contourImage, threshold);
        imwrite(DIR + name + "_threshold1.png", threshold);

        for (int contourIndex = 0; contourIndex < contours.size(); contourIndex++) {
            Mat currentContour = contours.get(contourIndex);
            if (currentContour != null) {

                Rect boundRect = boundingRect(currentContour);
                int count = countNonZero(new Mat(contourImage, boundRect));

                int cx = boundRect.x();
                int cy = boundRect.y();
                int contour_width = boundRect.width();
                int contour_height = boundRect.height();
                if ((contour_width < 100 && contour_height < 100) && (count > 81)) {    // Remove Non Canceour Tumor
//                    System.out.println("getting here " + contour_width);
                    drawContours(threshold, contours, contourIndex, Scalar.BLACK, CV_FILLED, 8, null, 0, new Point());
                    drawContours(rawImage, contours, contourIndex, Scalar.GREEN, CV_FILLED, 8, null, 0, new Point());
                }

            }
        }

        imwrite(DIR + name + "_threshold3.png", threshold);


        System.out.println("rawImage " + rawImage + " " + rawImage.type() + " " + CV_8UC3 + " " + CV_32SC1);




        bitwise_not(threshold, threshold);
        imwrite(DIR + name + "_threshold2.png", threshold);
        imwrite(DIR + name + "_contourImage0.png", contourImage);
        bitwise_and(grayImageCopy, contourImage, grayImageCopy);
        imwrite(DIR + name + "_contourImage1.png", grayImageCopy);

        bitwise_and(grayImageCopy, threshold, grayImageCopy);

        imwrite(DIR + name + "_contourImage3.png", grayImageCopy);
        threshold(grayImageCopy, grayImageCopy, 80, 255, CV_THRESH_BINARY);
        imwrite(DIR + name + "_nodules.png", grayImageCopy);
        my_kernel = createKernel(5);
        morphologyEx(grayImageCopy, grayImageCopy, MORPH_OPEN, my_kernel);
        imwrite(DIR + name + "_nodules_op.png", grayImageCopy);

        bitwise_and(grayImageCopy, threshold, grayImageCopy);
        imwrite(DIR + name + "_contourImage2.png", grayImageCopy);
        BrainTumorHelper.nonZeroTumor = countNonZero(grayImageCopy);
        System.out.println("====>>>> " + name + "==>" + nonZeroTumor);
        if (nonZeroTumor < CANCEROUS_) {
            Mat m22 = new Mat(grayImageCopy.size(), grayImageCopy.channels(), Scalar.BLACK);
            imwrite(DIR + name + "_contourImage4.png", m22);
            m22.release();
            result=0;
        } else {
            imwrite(DIR + name + "_contourImage4.png", grayImageCopy);
            result=1;
        }
        imwrite(DIR + name + "_nodules2.png", rawImage);
        rawImage.release();
        grayImage.release();
        grayImageCopy.release();
        threshold.release();
        contourImage.release();
        contours.deallocate();
        String[] args2 = new String[]{
            file1.getAbsolutePath(),
            DIR + name + "_knn.png",
            "4",
            "-c"
        };
        KNN.applyKmeans(args2);

       
        
        
//     bitwise_and(contourImage, threshold, contourImage);
        if (true) {
            return;
        }



    }
public static double result=0;
    public static double getRandomInt(int min, int max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    public static void process3(File file1) {
        int kernelSize = 5;
        Mat kernel = Mat.ones(new Size(kernelSize, kernelSize), CV_32F).asMat();
        double d = 1.0 / 25;
        kernel = multiply(kernel, d).asMat();
        FloatRawIndexer imagePixels = kernel.createIndexer();
//                Mat max=new Mat(1,4,1);
//                double d[]=new double[10];
//		minMaxLoc(hsvImage, d);
//                System.out.println("max "+max+" "+d[0]);
        float max = -1;
        for (int row = 0; row < kernel.rows(); row++) {
//            System.out.print(row + ",");
            for (int col = 0; col < kernel.cols(); col++) {
// if(mat.get(row, col)!=255&&mat.get(row, col)!=0)
                max = imagePixels.get(row, col);
                System.out.print(max + ",");
//                  
            }
            System.out.print("\n");
        }


        opencv_core.Mat rawImage = null;

        String name = file1.getName();
        rawImage = OpenCVHelper.file2mat(file1.getAbsolutePath());
        opencv_core.Mat rawImageCopy = rawImage.clone();
        Mat m22 = new Mat(rawImage.size(), CV_32FC4);
        cvtColor(rawImage, m22, CV_BGR2Lab);

        MatVector vec = new MatVector();
        split(m22, vec);
        Mat m2 = vec.get(0);

        imwrite("D:\\temp\\" + name + "_green.png", m2);
        Mat gray = new Mat(rawImage.size(), CV_8UC1);

//        cvtColor(rawImage, gray, CV_BGR2GRAY);
        CLAHE clahe = createCLAHE(5, new Size(8, 8));
        Mat clahe_op = new Mat(rawImage.size(), CV_8UC1);
        clahe.apply(m2, clahe_op);
        imwrite("D:\\temp\\" + name + "_clahe_op.png", clahe_op);
//        equalizeHist(clahe_op, clahe_op);
//        blur(clahe_op, clahe_op, new Size(8, 8));
//        GaussianBlur(clahe_op, clahe_op, new Size(5, 5), 0);



        filter2D(clahe_op, clahe_op, -1, kernel);


        imwrite("D:\\temp\\" + name + "_kernel.png", clahe_op);
        threshold(clahe_op, clahe_op, 150, 255, THRESH_BINARY);
//        Mat element = getStructuringElement(MORPH_OPEN, new Size(9, 9));
//        imwrite("D:\\temp\\" + name + "clahe_filtered.png", clahe_op);
//        dilate(clahe_op, clahe_op, element);
        imwrite("D:\\temp\\" + name + "clahe_dilate.png", clahe_op);
//        adaptiveThreshold(clahe_op, clahe_op, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 2);
//        imwrite("D:\\temp\\" + name + "clahe_thresho.png", clahe_op);

    }

    public static void process2(File file1) {
        opencv_core.Mat rawImage = null;

        String name = file1.getName();
        rawImage = OpenCVHelper.file2mat(file1.getAbsolutePath());
        opencv_core.Mat rawImageCopy = rawImage.clone();
        /*
         * List<Mat> channels = new LinkedList(); Core.split(labImage,channels);
         * CLAHE clahe = Imgproc.createCLAHE() Mat destImage = new
         * Mat(buffImage.getHeight(),buffImage.getWidth(), CvType.CV_8UC4);
         * clahe.apply(channels[0], destImage);
         * Imgproc.merge(channels,labImage);
         */
        Mat m2 = new Mat(rawImage.size(), CV_32FC4);
        cvtColor(rawImage, m2, CV_BGR2Lab);

        imwrite("D:\\temp\\" + name + "_lab.png", m2);
        MatVector vec = new MatVector();
        split(m2, vec);


        CLAHE clahe = createCLAHE(0.9, new Size(8, 8));
        Mat clahe_op = new Mat(rawImage.size(), CV_8UC1);

//        CLAHE clahe = new CLAHE();
//        Mat destImage = new Mat(rawImage.rows(),rawImage.cols(),CV_8UC4);
        Mat m = vec.get(0);
        System.out.println(m);
//        clahe.apply(m, destImage); 
        clahe.apply(m, clahe_op);
        System.out.println(vec.get(0));


        Mat thresholdedImage2 = new Mat(rawImage.size(), CV_8UC1);
//        System.out.println("T "+(THRESH_BINARY + THRESH_OTSU));
//        System.out.println("T "+(THRESH_BINARY | THRESH_OTSU));
        threshold(clahe_op, thresholdedImage2, 50, 255, THRESH_BINARY);
//        adaptiveThreshold(boxFiltered, thresholdedImage, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY_INV, 11, 2);

        imwrite("D:\\temp\\" + name + "_thresh2.png", thresholdedImage2);

        imwrite("D:\\temp\\" + name + "_clahe.png", clahe_op);

        imwrite("D:\\temp\\" + name + "_l.png", vec.get(0));

        imwrite("D:\\temp\\" + name + "_a.png", vec.get(1));

        imwrite("D:\\temp\\" + name + "_b.png", vec.get(2));

//        imwrite("D:\\temp\\" + name + "_destImage.png", destImage);



        Mat greenChannel = new Mat();
        extractChannel(rawImageCopy, greenChannel, 1);  // BGR (012)
        imwrite("D:\\temp\\" + name + "_red.png", greenChannel);
        opencv_core.Mat gray_my = greenChannel;
//        cvtColor(greenChannel, gray_my, CV_BGR2GRAY);
        imwrite("D:\\temp\\" + name + "_gray.png", gray_my);
        equalizeHist(gray_my, gray_my);

        imwrite("D:\\temp\\" + name + "_gray2.png", gray_my);
        Mat boxFiltered = new opencv_core.Mat(rawImage.rows(), rawImage.cols(), 1);
        boxFilter(gray_my, boxFiltered, -1, new Size(9, 9), new Point(-1, -1), true, BORDER_DEFAULT);
        imwrite("D:\\temp\\" + name + "_box.png", boxFiltered);
        absdiff(gray_my, boxFiltered, boxFiltered);
        imwrite("D:\\temp\\" + name + "_sub.png", boxFiltered);
        opencv_core.Mat thresholdedImage = new opencv_core.Mat(rawImage.rows(), rawImage.cols(), 1);
        threshold(gray_my, thresholdedImage, 60, 255, THRESH_OTSU);
//        adaptiveThreshold(boxFiltered, thresholdedImage, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY_INV, 11, 2);
        imwrite("D:\\temp\\" + name + "_thresh.png", thresholdedImage);


        opencv_core.Mat hsvImage = new opencv_core.Mat(rawImage.rows(), rawImage.cols(), rawImage.type());
        cvtColor(rawImage, hsvImage, CV_BGR2HSV);

//            inRange(hsvImage, new Mat(new Size(4, 1), CV_64FC1, zeroScalar), new Mat(new Size(4, 1), CV_64FC1, black_level), mask);
        opencv_core.Mat hsv2 = hsvImage.clone();
        imwrite("D:\\temp\\" + name + "_hsv.png", hsvImage);


//        Mat m = new Mat();
        Mat value = new Mat();
        extractChannel(hsvImage, value, 2);
//        System.out.println(rawImage.createIndexer());
        UByteIndexer imagePixels = rawImage.createIndexer();
//                Mat max=new Mat(1,4,1);
//                double d[]=new double[10];
//		minMaxLoc(hsvImage, d);
//                System.out.println("max "+max+" "+d[0]);
        int max = -1;
        for (int row = 0; row < value.rows(); row++) {
//            System.out.print(row + ",");
            for (int col = 0; col < value.cols(); col++) {
// if(mat.get(row, col)!=255&&mat.get(row, col)!=0)
                if (imagePixels.get(row, col) > max) {
                    max = imagePixels.get(row, col);
                }
//                            System.out.print(imagePixels.get(row,col) + ",");
            }
//			System.out.print("\n");
        }
        System.out.println("max" + max);
//        max(rawImage, m);
//        System.out.println("d " + value);
        inRange(hsvImage, new opencv_core.Mat(new int[]{0, 0, (max - (int) (0.10f * max))}), new opencv_core.Mat(new int[]{180, 255, max}), hsv2);
        imwrite("D:\\temp\\" + name + "_filtered.png", hsv2);
        hsvImage.release();
        hsv2.release();
        rawImage.release();
        m.release();
        value.release();
//        cvRelease(m);
//        cvRelease(value);

//        JOptionPane.showMessageDialog(null, "Check Images");


    }
}
