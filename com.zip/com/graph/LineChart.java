package com.graph;

import java.awt.BasicStroke;
import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYShapeRenderer;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class LineChart {

    public static void getLineChart(OutputStream out, ChartModel c, ArrayList<Integer> value1,
            ArrayList<Integer> value2) {
        XYSeries series = new XYSeries(c.getRow1());
        for (int i = 0; i < value1.size(); i++) {
            series.add(value1.get(i), value2.get(i));
        }
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);

        JFreeChart chart = ChartFactory.createXYLineChart(c.graphTitle,
                c.xAxisTitle, c.yAxisTitle, dataset, PlotOrientation.VERTICAL,
                true, true, false);

        try {
            ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(), c.getHeight());
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }
    }

    public static void getLineChart(OutputStream out, ArrayList<Integer> value1,
            ArrayList<Integer> value2) {
        ChartModel c = new ChartModel();
        XYSeries series = new XYSeries(c.getRow1());
        for (int i = 0; i < value1.size(); i++) {
            series.add(value1.get(i), value2.get(i));
        }
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);

        JFreeChart chart = ChartFactory.createXYLineChart(c.graphTitle,
                c.xAxisTitle, c.yAxisTitle, dataset, PlotOrientation.VERTICAL,
                true, true, false);

        try {
            ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(), c.getHeight());
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }
    }

    public static void getLineChart(OutputStream out, ArrayList<Double> value1) {
        ChartModel c = new ChartModel();
        System.out.println(value1.size());
        XYSeries series = new XYSeries(c.getRow1());
        for (int i = 0; i < value1.size(); i++) {
            System.out.println((i + 1) + ":" + value1.get(i));
            series.add((i + 1), value1.get(i));
        }
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);

        JFreeChart chart = ChartFactory.createXYLineChart(c.graphTitle,
                c.xAxisTitle, c.yAxisTitle, dataset, PlotOrientation.VERTICAL,
                true, true, false);

        try {
            ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(), c.getHeight());
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }
    }

    public static JFreeChart getLineChart(OutputStream out, ArrayList<Double> value1,
            ArrayList<Double> value2, ArrayList<Double> value3, ArrayList<Double> value4) {
        ChartModel c = new ChartModel();
        System.out.println(value1.size());
        XYSeries series1 = new XYSeries("Feature1");
        XYSeries series2 = new XYSeries("Feature2 E4"); // * 10000
        XYSeries series3 = new XYSeries("Feature3 E4"); // * 10000
        
        for (int i = 0; i < value1.size(); i++) {
            //System.out.println((i+1)+":"+value1.get(i));
            series1.add((i + 1), value1.get(i));
            series2.add((i + 1), value2.get(i));
            series3.add((i + 1), value3.get(i));
        
        }
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series1);
        dataset.addSeries(series2);
        dataset.addSeries(series3);
//        dataset.addSeries(series4);

        JFreeChart chart = ChartFactory.createXYLineChart(c.graphTitle,
                c.xAxisTitle, c.yAxisTitle, dataset, PlotOrientation.VERTICAL,
                true, true, false);

        try {
            ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(), c.getHeight());
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }
        return chart;
    }

    /*
     * public static void getLineChartNew2(OutputStream out, ArrayList<Integer>
     * value1, ArrayList<Integer> value2, ArrayList<String> value3, double
     * valMax1, String title) { ChartModel c = new ChartModel(); TimeSeries
     * series1 = new TimeSeries("Actual"); TimeSeries series2 = new
     * TimeSeries("Predicted"); ArrayList<Date> dates = new ArrayList<Date>();
     * for(int i=0;i<value3.size();i++){ String date= value3[i]; String[]
     * splitDates = }
     *
     * for (int i = 0; i < value1.size(); i++){ //series1.add(value3.get(i),
     * value1.get(i)); //series2.add(value3.get(i), value2.get(i)); }
     * TimeSeriesCollection dataset = new TimeSeriesCollection();
     * dataset.addSeries(series1); dataset.addSeries(series2);
     *
     * JFreeChart chart = ChartFactory.createTimeSeriesChart(title, "Date(s)",
     * "Stock Price", dataset, true, true, false);
     *
     * XYPlot xyPlot = (XYPlot) chart.getPlot(); XYLineAndShapeRenderer renderer
     * = new XYLineAndShapeRenderer( ); xyPlot.setRenderer( renderer ); DateAxis
     * axis = (DateAxis) xyPlot.getDomainAxis(); axis.setDateFormatOverride(new
     * SimpleDateFormat("dd-MMM-yyyy")); NumberAxis range = (NumberAxis)
     * xyPlot.getRangeAxis(); range.setRange((valMax1-100), (valMax1+100));
     * range.setTickUnit(new NumberTickUnit(20));
     *
     * try { ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(),
     * c.getHeight()); } catch (IOException e) { System.err.println("Problem
     * occurred creating chart."); }
	}
     */
    public static JFreeChart getLineChartNew(OutputStream out, ArrayList<Integer> value1,
            ArrayList<Integer> value2, ArrayList<Integer> value3, double valMax1, String title) {
        ChartModel c = new ChartModel();
        XYSeries series1 = new XYSeries("Actual");
        XYSeries series2 = new XYSeries("Predicted");
        for (int i = 0; i < value1.size(); i++) {
            series1.add(value3.get(i), value1.get(i));
            series2.add(value3.get(i), value2.get(i));
        }
        XYSeriesCollection dataset = new XYSeriesCollection();

        dataset.addSeries(series1);
        dataset.addSeries(series2);

        JFreeChart chart = ChartFactory.createXYLineChart(title,
                "Date(s)", "Stock Price", dataset, PlotOrientation.VERTICAL,
                true, true, false);

        XYPlot xyPlot = (XYPlot) chart.getPlot();
        //NumberAxis domain = (NumberAxis) xyPlot.getDomainAxis();
        //domain.setRange(0.00, 1.00);
        //domain.setTickUnit(new NumberTickUnit(0.1));
        //domain.setVerticalTickLabels(true);
        //XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) xyPlot.getRenderer();
        //renderer.setBaseItemLabelsVisible(true);

        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        //renderer.setSeriesPaint( 0 , Color.RED );
        //renderer.setSeriesPaint( 1 , Color.GREEN );
        //renderer.setSeriesPaint( 2 , Color.YELLOW );
        //renderer.setSeriesStroke( 0 , new BasicStroke( 4.0f ) );
        //renderer.setSeriesStroke( 1 , new BasicStroke( 1.0f ) );
        //renderer.setSeriesStroke( 2 , new BasicStroke( 2.0f ) );
        xyPlot.setRenderer(renderer);

        NumberAxis range = (NumberAxis) xyPlot.getRangeAxis();
        range.setRange((valMax1 - 100), (valMax1 + 100));
        range.setTickUnit(new NumberTickUnit(20));

        try {
            ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(), c.getHeight());
        } catch (IOException e) {
            System.err.println("Problem occurred creating chart.");
        }
        return chart;
    }
}
