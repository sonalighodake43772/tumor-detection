package com.graph;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.Day;
import org.jfree.data.time.Hour;
import org.jfree.data.time.Minute;
import org.jfree.data.time.Month;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.Year;
import org.jfree.data.xy.XYDataset;


public class TimeSeriesChart {
	public static JFreeChart getTimeSeriesGraph(OutputStream out, ChartModel c,
			ArrayList<Date> days, ArrayList<Integer> value, MyDate m) {
		TimeSeries pop;
		if (m == MyDate.MONTH) {//same year but for different months
			pop = new TimeSeries(c.row1, Month.class); 
			for (int i = 0; i < days.size(); i++)
				pop.add(new Month(days.get(i)), value.get(i));
		} else if (m == MyDate.DAY) { //different days in same month or year
			pop = new TimeSeries(c.row1, Day.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Day(days.get(i)), value.get(i));
		} else if (m == MyDate.YEAR) { //graph for different years
			pop = new TimeSeries(c.row1, Year.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Year(days.get(i)), value.get(i));
		} else if (m == MyDate.HOUR) { //in same day different hours
			pop = new TimeSeries(c.row1, Hour.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Hour(days.get(i)), value.get(i));
		} else if (m == MyDate.MINUTE) { // in same day different minutes
			pop = new TimeSeries(c.row1, Minute.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Minute(days.get(i)), value.get(i));
		} else { // in same day different seconds
			pop = new TimeSeries(c.row1, Second.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Second(days.get(i)), value.get(i));
		}

		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.setDomainIsPointsInTime(true);
		dataset.addSeries(pop);
		XYDataset data1 = dataset;
		JFreeChart chart = ChartFactory.createTimeSeriesChart(
				c.getGraphTitle(), c.xAxisTitle, c.yAxisTitle, data1, true,
				true, false);
		XYPlot plot = (XYPlot) chart.getPlot();
		final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesLinesVisible(0, true);
		renderer.setSeriesShapesVisible(1, true);
		plot.setRenderer(renderer);

		ValueAxis xAxis = (ValueAxis) plot.getDomainAxis();
		xAxis.setVerticalTickLabels(true);
		try {
			ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(),
					c.getHeight());
		} catch (IOException e) {
			System.err.println("Problem occurred creating chart.");
		}
        return chart;
	}

	public static enum MyDate {
		MONTH, DAY, YEAR, HOUR, SECOND, MINUTE
	}

	public static void getTimeSeriesGraph(OutputStream out,
			ArrayList<Date> days, ArrayList<Integer> value, MyDate m) {
		ChartModel c = new ChartModel();
		TimeSeries pop;
		if (m == MyDate.MONTH) {//same year but for different months
			pop = new TimeSeries(c.row1, Month.class); 
			for (int i = 0; i < days.size(); i++)
				pop.add(new Month(days.get(i)), value.get(i));
		} else if (m == MyDate.DAY) { //different days in same month or year
			pop = new TimeSeries(c.row1, Day.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Day(days.get(i)), value.get(i));
		} else if (m == MyDate.YEAR) { //graph for different years
			pop = new TimeSeries(c.row1, Year.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Year(days.get(i)), value.get(i));
		} else if (m == MyDate.HOUR) { //in same day different hours
			pop = new TimeSeries(c.row1, Hour.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Hour(days.get(i)), value.get(i));
		} else if (m == MyDate.MINUTE) { // in same day different minutes
			pop = new TimeSeries(c.row1, Minute.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Minute(days.get(i)), value.get(i));
		} else { // in same day different seconds
			pop = new TimeSeries(c.row1, Second.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Second(days.get(i)), value.get(i));
		}

		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.setDomainIsPointsInTime(true);
		dataset.addSeries(pop);
		XYDataset data1 = dataset;
		JFreeChart chart = ChartFactory.createTimeSeriesChart(
				c.getGraphTitle(), c.xAxisTitle, c.yAxisTitle, data1, true,
				true, false);
		XYPlot plot = (XYPlot) chart.getPlot();
		final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesLinesVisible(0, true);
		renderer.setSeriesShapesVisible(1, true);
		plot.setRenderer(renderer);

		ValueAxis xAxis = (ValueAxis) plot.getDomainAxis();
		xAxis.setVerticalTickLabels(true);
		try {
			ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(),
					c.getHeight());
		} catch (IOException e) {
			System.err.println("Problem occurred creating chart.");
		}
	}

	public static void getTimeSeriesGraph(OutputStream out,
			ArrayList<Date> days, ArrayList<Date> days2,
			ArrayList<Integer> value, ArrayList<Integer> value2, MyDate m) {
		ChartModel c = new ChartModel();
		TimeSeries pop;
		TimeSeries pop2;
		if (m == MyDate.MONTH) {//same year but for different months
			pop = new TimeSeries(c.row1, Month.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Month(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Month.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Month(days2.get(i)), value2.get(i));
		} else if (m == MyDate.DAY) { //different days in same month or year
			pop = new TimeSeries(c.row1, Day.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Day(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Day.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Day(days2.get(i)), value2.get(i));
		} else if (m == MyDate.YEAR) { //graph for different years
			pop = new TimeSeries(c.row1, Year.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Year(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Year.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Year(days2.get(i)), value2.get(i));
		} else if (m == MyDate.HOUR) {//in same day different hours
			pop = new TimeSeries(c.row1, Hour.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Hour(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Hour.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Hour(days2.get(i)), value2.get(i));
		} else if (m == MyDate.MINUTE) {// in same day different minutes
			pop = new TimeSeries(c.row1, Minute.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Minute(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Minute.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Minute(days2.get(i)), value2.get(i));
		} else {// in same day different seconds
			pop = new TimeSeries(c.row1, Second.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Second(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Second.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Second(days2.get(i)), value2.get(i));
		}

		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.setDomainIsPointsInTime(true);
		dataset.addSeries(pop);
		dataset.addSeries(pop2);
		XYDataset data1 = dataset;
		JFreeChart chart = ChartFactory.createTimeSeriesChart(
				c.getGraphTitle(), c.xAxisTitle, c.yAxisTitle, data1, true,
				true, false);
		XYPlot plot = (XYPlot) chart.getPlot();
		final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesLinesVisible(0, true);
		renderer.setSeriesShapesVisible(1, true);
		plot.setRenderer(renderer);

		ValueAxis xAxis = (ValueAxis) plot.getDomainAxis();
		xAxis.setVerticalTickLabels(true);
		try {
			ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(),
					c.getHeight());
		} catch (IOException e) {
			System.err.println("Problem occurred creating chart.");
		}
	}

	public static JFreeChart getTimeSeriesGraph(OutputStream out, ChartModel c,
			ArrayList<Date> days, ArrayList<Date> days2,
			ArrayList<Integer> value, ArrayList<Integer> value2, MyDate m) {
		TimeSeries pop;
		TimeSeries pop2;
		if (m == MyDate.MONTH) {//same year but for different months
			pop = new TimeSeries(c.row1, Month.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Month(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Month.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Month(days2.get(i)), value2.get(i));
		} else if (m == MyDate.DAY) { //different days in same month or year
			pop = new TimeSeries(c.row1, Day.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Day(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Day.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Day(days2.get(i)), value2.get(i));
		} else if (m == MyDate.YEAR) { //graph for different years
			pop = new TimeSeries(c.row1, Year.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Year(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Year.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Year(days2.get(i)), value2.get(i));
		} else if (m == MyDate.HOUR) {//in same day different hours
			pop = new TimeSeries(c.row1, Hour.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Hour(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Hour.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Hour(days2.get(i)), value2.get(i));
		} else if (m == MyDate.MINUTE) {// in same day different minutes
			pop = new TimeSeries(c.row1, Minute.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Minute(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Minute.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Minute(days2.get(i)), value2.get(i));
		} else {// in same day different seconds
			pop = new TimeSeries(c.row1, Second.class);
			for (int i = 0; i < days.size(); i++)
				pop.add(new Second(days.get(i)), value.get(i));

			pop2 = new TimeSeries(c.row2, Second.class);
			for (int i = 0; i < days.size(); i++)
				pop2.add(new Second(days2.get(i)), value2.get(i));
		}

		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.setDomainIsPointsInTime(true);
		dataset.addSeries(pop);
		dataset.addSeries(pop2);
		XYDataset data1 = dataset;
		JFreeChart chart = ChartFactory.createTimeSeriesChart(
				c.getGraphTitle(), c.xAxisTitle, c.yAxisTitle, data1, true,
				true, false);
		XYPlot plot = (XYPlot) chart.getPlot();
		final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesLinesVisible(0, true);
		renderer.setSeriesShapesVisible(1, true);
		plot.setRenderer(renderer);

		ValueAxis xAxis = (ValueAxis) plot.getDomainAxis();
		xAxis.setVerticalTickLabels(true);
		try {
			ChartUtilities.writeChartAsPNG(out, chart, c.getWidth(),
					c.getHeight());
		} catch (IOException e) {
			System.err.println("Problem occurred creating chart.");
		}
        return chart;
	}
	
	public static void getTimeChartNew(OutputStream out, HashMap<String, Integer> reqMap, String title) {
		
		ChartModel c = new ChartModel();
		
		TimeSeries series1 = new TimeSeries("Actual");
		ArrayList<Date> dates = new ArrayList<Date>();
		
		for (String key : reqMap.keySet()) {
			Date d = new Date(Long.parseLong(key) * 1000);
			series1.add(new Second(d), reqMap.get(key));
		}
		
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		
		dataset.addSeries(series1);
		
		JFreeChart chart = ChartFactory.createTimeSeriesChart(title,
				"Time(s)", "Requests", dataset,
				true, true, false);
		
		XYPlot xyPlot = (XYPlot) chart.getPlot();
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesLinesVisible(0, true);
		renderer.setSeriesShapesVisible(1, true);
	    xyPlot.setRenderer( renderer ); 
		
		try {
			ChartUtilities.writeChartAsPNG(out, chart,  c.getWidth(), c.getHeight());
		} catch (IOException e) {
			System.err.println("Problem occurred creating chart.");
		}
	}
	public static void createGraph(OutputStream out,HashMap values){
		  JFreeChart lineChart = ChartFactory.createLineChart(
			         "Anamoly Detection For Javaw.exe",
			         "Days Ago","Number of IO",
			         createDataset(values),
			         PlotOrientation.VERTICAL,
			         true,true,false);
			try {
				ChartUtilities.writeChartAsPNG(out, lineChart, 500, 300);
			} catch (IOException e) {
				System.err.println("Problem occurred creating chart.");
			}
	}
	 private static DefaultCategoryDataset createDataset(HashMap values )
	   {
	      DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
	      
	      dataset.addValue( 77 , "javaw.exe" , "7" );
	      dataset.addValue( 45 , "javaw.exe" , "6" );
	      dataset.addValue( 77 , "javaw.exe" ,  "5" );
	      dataset.addValue( 77 , "javaw.exe" , "4" );
	      dataset.addValue( 45 , "javaw.exe" , "3" );
	      dataset.addValue( 45 , "javaw.exe" , "2" );
	      dataset.addValue( 45 , "javaw.exe" , "1" );
	      
	      return dataset;
	   }
	@SuppressWarnings("deprecation")
	public static void getTimeChart(OutputStream out, ArrayList<Double> value1,
			ArrayList<Double> value2, ArrayList<Double> value3, ArrayList<Double> value4, ArrayList<String> value5) {
		
		ChartModel c = new ChartModel();
		/*TimeSeries series1 = new TimeSeries("Actual");*/
		TimeSeries series2 = new TimeSeries("Regression");
		TimeSeries series3 = new TimeSeries("Moving Average");
		TimeSeries series4 = new TimeSeries("Forecasting");
		TimeSeries series5 = new TimeSeries("Neural Network");
		ArrayList<Date> dates = new ArrayList<Date>();
		
		int minLen = Math.min(value1.size(),Math.min(value2.size(),Math.min(value3.size(),Math.min(value4.size() ,value5.size()))));
		
		for(int i=0;i<minLen;i++){
			String date = value5.get(i);
			String[] datesSeperate = date.split("-");
			dates.add(new Date(Integer.parseInt(datesSeperate[0]), Integer.parseInt(datesSeperate[1])-1, Integer.parseInt(datesSeperate[2])));
		}
		
		for (int i = 0; i < minLen; i++){
			//series1.add(value3.get(i), value1.get(i));
			//series2.add(value3.get(i), value2.get(i));
			Day d = new Day(dates.get(i));
			/*series1.add(d, value1.get(i));*/
			series2.add(d, value1.get(i));
			series3.add(d, value2.get(i));
			series4.add(d, value3.get(i));
			series5.add(d, value4.get(i)); 
		}
		
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.addSeries(series2);
		dataset.addSeries(series3);
		dataset.addSeries(series4);
		dataset.addSeries(series5);
		
		JFreeChart chart = ChartFactory.createTimeSeriesChart("Predicted Values for Today",
				"Date(s)", "Stock Price", dataset,
				true, true, false);
		
		XYPlot xyPlot = (XYPlot) chart.getPlot();
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesLinesVisible(0, true);
		renderer.setSeriesShapesVisible(1, true);
	    xyPlot.setRenderer( renderer ); 
	    
	    try {
			ChartUtilities.writeChartAsPNG(out, chart,  c.getWidth(), c.getHeight());
		} catch (IOException e) {
			System.err.println("Problem occurred creating chart.");
		}
		
	}
	
	public static void getTimeChartAll(OutputStream out, ArrayList<Integer> value1,
			ArrayList<Integer> value2 , ArrayList<Integer> value3, ArrayList<Integer> value4,
			ArrayList<Integer> value5, ArrayList<String> value6, double valMax1, String title) {
		
		ChartModel c = new ChartModel();
		
		TimeSeries series1 = new TimeSeries("Actual");
		TimeSeries series2 = new TimeSeries("Regression");
		TimeSeries series3 = new TimeSeries("Moving Average");
		TimeSeries series4 = new TimeSeries("Forecasting");
		TimeSeries series5 = new TimeSeries("Neural Network");
		ArrayList<Date> dates = new ArrayList<Date>();
		
		int minLen = Math.min(value1.size(),Math.min(value2.size(),Math.min(value3.size(),Math.min(value4.size() ,value5.size()))));
		
		for(int i=0;i<minLen;i++){
			String date = value6.get(i);
			String[] datesSeperate = date.split("-");
			dates.add(new Date(Integer.parseInt(datesSeperate[0]), Integer.parseInt(datesSeperate[1])-1, Integer.parseInt(datesSeperate[2])));
		}
		
		//dates.add(new Date(2014, 1, 1));
		//dates.add(new Date(2014, 3, 1));
		//dates.add(new Date(2014, 5, 1));
		//dates.add(new Date(2014, 7, 1));	
		
		//	for(int i=0;i<value3.size();i++){
		//		String date= value3[i];
		//		String[] splitDates = 
		//	}
		
		for (int i = 0; i < minLen; i++){
			//series1.add(value3.get(i), value1.get(i));
			//series2.add(value3.get(i), value2.get(i));
			Day d = new Day(dates.get(i));
			series1.add(d, value1.get(i));
			series2.add(d, value2.get(i));
			series3.add(d, value3.get(i));
			series4.add(d, value4.get(i));
			series5.add(d, value5.get(i));
		}
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		
		dataset.addSeries(series1);
		dataset.addSeries(series2);
		dataset.addSeries(series3);
		dataset.addSeries(series4);
		dataset.addSeries(series5);
		
		JFreeChart chart = ChartFactory.createTimeSeriesChart(title,
				"Date(s)", "Stock Price", dataset,
				true, true, false);
		
		XYPlot xyPlot = (XYPlot) chart.getPlot();
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesLinesVisible(0, true);
		renderer.setSeriesShapesVisible(1, true);
	    xyPlot.setRenderer( renderer ); 
	    //DateAxis axis = (DateAxis) xyPlot.getDomainAxis();
	    //axis.setDateFormatOverride(new SimpleDateFormat("dd-MMM-yyyy"));
		//NumberAxis range = (NumberAxis) xyPlot.getRangeAxis();
        //range.setRange((valMax1-75), (valMax1+75));
        //range.setTickUnit(new NumberTickUnit(20));
		
		try {
			ChartUtilities.writeChartAsPNG(out, chart,  c.getWidth(), c.getHeight());
		} catch (IOException e) {
			System.err.println("Problem occurred creating chart.");
		}
	}
}
